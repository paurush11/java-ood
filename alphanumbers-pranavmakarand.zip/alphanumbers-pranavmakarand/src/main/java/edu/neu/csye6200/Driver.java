package edu.neu.csye6200;

/**
 * @author SaiAkhil
 */
public class Driver {
    public static void main(String[] args) {
        System.out.println("============Main Execution Start===================\n\n");

        //Add your code in between these two print statements
//        AlphaNumbers2.demo()
        
        AlphaNumbers.demo();

        System.out.println("\n\n============Main Execution End===================");
    }
}
